/*
 * Libby Bakalar
 * This program will calculate the total number of cases of each pop sold and the total sales amount of 
 * money per team. This program includes the use of arrays. 
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class PopSalesArray {
	//variables
	static Scanner myScanner;
	static String iRecord = "";
	static PrintWriter pwValid;													//used to write data to the valid prt
	static PrintWriter pwError;													//used to write data to the error prt
	static LocalDate today = LocalDate.now();									//holds current date, without time portion 
	static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");	//used to format date 
	static NumberFormat nf;	
	
	//String variables	
	static String[] arrErrMsg = {"Last name required", "First name required", "Address Required",  
								"City Required", "Invalid State", "Zip Code must be numeric", 
								"Pop Type invalid", "Cases must be greater than zero", "Cases must be numeric", 
								"Invalid team. Team must be A, B, C, D, AND E"};	
	static String[] arrPopType = {"Coke", "Diet Coke", "Mellow Yellow", "Cherry Coke", "Diet Cherry Coke", "Sprite"};
	static String[] arrState = {"IA", "IL", "MI", "MO", "NE", "WI"};
	static String arrTeams[] = {"A","B","C","D","E"};
	static String iLastName;
	static String iFirstName;
	static String iAddress;
	static String iCity; 
	static String iState; 
	static String iZipp; 
	static String iPopTypee; 
	static String iNumCasess; 
	static String iTeam; 
	static String aPop, bPop, cPop;
	
	static String oTotal;
	static String oDeposit; 
	static String oTeam;
	static String oMsg;
	
	//double variables
	static double[] arrDeposit = {1.2, 0.0, 2.4, 0.0, 1.2, 1.2}; // deposits (already taken the .05 or .10 times the 24 bottles)
	static double[] arrTotal = new double[5];
	
	static double cPrice = 18.71;
	static double cDeposit; 
	static double cTotal; 
	
	//int variables
	static int[] arrTotNumCases = new int[6];
	static int[] arrPopTypeNum = {01,02,03,04,05,06}; 
	static int cPCtr=0, cErrPCtr=0;
	static int cErrCtr=0;
	
	static int i=0, index;
	static int iZip;
	static int iNumCases;
	static int iPopType; 
	
	static int aPopCtr=0, bPopCtr=0, cPopCtr=0; 
	
	//boolean variables
	static boolean eof = false;
	static boolean errorSwitch;	
	
	public static void main(String[] args) {
		//call init
		init();
		
		while (!eof) {
			//call validate
			validate();
			
			if (!errorSwitch) {
				//call error routine
				errorReport();
			}
			else {
				//call calcs
				calcs();
				
				//call output
				output();
			}
			//call input
			input();
		}
		//call closing
		closing();
		
		//close output files
		pwValid.close();
		pwError.close();
		
	//bracket to end main
	}
	
	public static void init() {
		
		//set up to read from dat file
		try {
			myScanner = new Scanner(new File("JAVPOP.dat"));
			myScanner.useDelimiter(System.getProperty("line.separator"));
		}
		catch(FileNotFoundException e) {
			System.out.println("File Error");
			System.exit(1);			
		}
		
		nf = NumberFormat.getCurrencyInstance(java.util.Locale.US); 
		
		//set up to print to valid.prt
		try {
			pwValid = new PrintWriter(new File ("JAVPOPSLB.PRT"));
		} 
		catch (FileNotFoundException e) {
			System.out.println("Output file error");
		}
		
		//set up to print to error.prt
		try {
			pwError = new PrintWriter(new File ("JAVPOPERB.PRT"));
		} 
		catch (FileNotFoundException e) {
			System.out.println("Output file error");
		}
		
		for(int i = 0; i < 5; i++) {
			arrTotal[i] = 0;
		}
		 
		for(int i = 0; i < 6; i++) {
			arrTotNumCases[i] = 0;
		}
		 
		
		//call input
		input();
		
		//call headings
		headings();
		
		//call error headings
		errorHeadings();		
		
	//bracket to end init	
	}
	
	public static void input() {
		if(myScanner.hasNext()) {
			iRecord = myScanner.next();
			iLastName = iRecord.substring(0,15);
			iFirstName = iRecord.substring(15,30);
			iAddress = iRecord.substring(30,45);
			iCity = iRecord.substring(45,55);	
			iState = iRecord.substring(55,57);
			iZipp = iRecord.substring(57,66);
			iPopTypee = iRecord.substring(66,68);
			iNumCasess = iRecord.substring(68,70);
			iTeam = iRecord.substring(70,71);
		}
		else {
			eof = true;
		}
		
	//bracket to end input	
	}
	
	public static void headings() {
		cPCtr+=1; 
		
		//printed to pw1 - valid.prt
		pwValid.format("%-6s%-10s%36s%28s%44s%6s%2s\n", "Date: ", today.format(dtf), "", "Albia Soccer Club Fundraiser", "", "Page: ", cPCtr);
		pwValid.format("%8s%47s%19s\n", "JAVLMB06", "", "Bakalar Division");
		pwValid.format("%60s%12s\n\n", "", "Sales Report");
		pwValid.format("%-3s%9s%8s%10s%7s%4s%8s%6s%8s%4s%8s%13s%8s%6s%11s%6s%13s\n\n","", "Last Name","", "First Name", "", 
				"City", "", "State ", "Zip Code", "", "Pop Type","", "Quantity", "", "Deposit Amt", "", "Total Sales");   
	
		//bracket to end headings
	}
	
	public static void errorHeadings() {		
		cErrPCtr+=1; 
				
		//printed to pw2 - error.prt 
		pwError.format("%-6s%-10s%36s%28s%44s%6s%2s\n", "Date: ",today.format(dtf), "", "Albia Soccer Club Fundraiser", "", "Page: ", cErrPCtr);
		pwError.format("%8s%47s%19s\n", "JAVLMB06", "", "Bakalar Division");
		pwError.format("%60s%12s\n\n", "", "Error Report");
		pwError.format("%-12s%60s%-17s\n\n", "Error Record", "", "Error Message");
	
	//bracket to end error headings
	}
	
	public static void validate() {
		
		errorSwitch = false;
		
		//validate last name
		if(iLastName.trim().isEmpty()){
			oMsg = arrErrMsg[0];
			return;
		}
		
		//validate first name
		if(iFirstName.trim().isEmpty()) {
			oMsg = arrErrMsg[1];
			return;
		}
				
		//validate address
		if(iAddress.trim().isEmpty()) {
			oMsg = arrErrMsg[2];
			return;
		}
		
		//validate city
		if(iCity.trim().isEmpty()) {
			oMsg = arrErrMsg[3];
			return;
		}
		
		//validate state
		iState = iState.toUpperCase();
		for( i = 0; i < arrState.length; i++) {
			if(iState.equals(arrState[i])) {
				index = i;
				break;
			}
		}		
		if(i == arrState.length) {
			oMsg = arrErrMsg[4];
			return;
		}
		
		//validate zip - must be numeric
		try {
			iZip = Integer.parseInt(iZipp);
		}
		catch (NumberFormatException e) {
			oMsg = arrErrMsg[5];
			return;
		}		
		
		//validate pop type - must be 1-6 and numeric
		try {
			iPopType = Integer.parseInt(iPopTypee);
			if (iPopType < 1 || iPopType > 6) {
				 oMsg = arrErrMsg[6];
				 return;
			 }
		} catch (Exception e) {
			oMsg = arrErrMsg[6];
			return;
		}
		
		//validate num of cases - must be numeric and > 0
		try {
			iNumCases = Integer.parseInt(iNumCasess);
			 if (iNumCases < 1) {
				 oMsg = arrErrMsg[7];
				 return;
			 }
		}
		catch (NumberFormatException e) {
			oMsg = arrErrMsg[8];
			return;
		}
		
		//validate team - must be a-e
		iTeam = iTeam.toUpperCase();
		for( i = 0; i < arrTeams.length; i++) {
			if(iTeam.equals(arrTeams[i])) {
				index = i;
				break;
			}
		}		
		if(i == arrTeams.length) {
			oMsg = arrErrMsg[9];
			return;
		}
		errorSwitch = true;
		
	//bracket to end validate	
	}
	
	public static void errorReport() {		
		
		pwError.format("%-71s%1s%-60s\n\n", iRecord , "", oMsg);
		
		cErrCtr +=1;
		
	//bracket to end error report	
	}
	public static void calcs() {		
				
		arrTotNumCases[iPopType-1]+= iNumCases; 
		
		for(int i = 0; i < arrState.length; i++) {
			if (iState.equals(arrState[i]))
				cDeposit = (arrDeposit[i] * iNumCases);
				cTotal= (cPrice * iNumCases) + cDeposit;
		}
				
		for(int i = 0; i < arrTeams.length; i++) {
			if (iTeam.equals(arrTeams[i]))
				arrTotal[i] += cTotal; 
		}
		
	//bracket to end calcs	
	}	
	
	public static void output() {
		
		oDeposit = nf.format(cDeposit);
		oTotal = nf.format(cTotal);		
	
		pwValid.format("%-3s%15s%2s%15s%2s%10s%3s%2s%3s%9s%2s%-16s%8s%2s%11s%7s%9s%9s\n\n", "", iLastName,"", iFirstName, "", iCity, "", 
					iState, "", iZip, "", arrPopType[iPopType-1],"", iNumCases, "", oDeposit, "", oTotal);
		
				
	//bracket to end output	
	}
	
	public static void grandTotals() {
		
		headings();
		
		//print to both grand total lines
		pwValid.format("%-13s\n\n", "Grand Totals:");
		for(int i = 0; i < 4; i+=3) {
			pwValid.format("%-3s%-16s%1s%-7s%6s%-16s%1s%-7s%6s%-16s%1s%-7s\n\n", "", arrPopType[i], "", arrTotNumCases[i],  " ", 
					arrPopType[i+1], "", arrTotNumCases[i+1],  " ", arrPopType[i+2], "", arrTotNumCases[i+2]);
		}
		
		pwValid.format("%-12s\n\n", "Team Totals:");
		for(int i = 0; i < arrTeams.length; i++) {
			oTotal = nf.format(arrTotal[i]);
			pwValid.format("%-3s%1s%1s%15s\n\n", "", arrTeams[i],  " ", oTotal);
		}		
		
	//bracket to end grand totals	
	}
	
	public static void errorTotals() {		
		
		pwError.format("%-12s%5s", "Total Errors: ", cErrCtr);
						
	//bracket to end error totals	
	}
	
	public static void closing() {
		//call grandtotals
		grandTotals(); 
		
		//call error routine
		errorTotals(); 
		
	//bracket to end closing
	}	
	
//bracket to end program
}
