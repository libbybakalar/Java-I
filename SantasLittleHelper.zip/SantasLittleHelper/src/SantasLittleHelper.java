import java.text.NumberFormat;
import java.util.Scanner;

//*Libby Bakalar*//
//*12/3/2018*//
//*calculates toy prices*//
public class SantasLittleHelper {
	
	//declaring variables
	static String iFirstName; 		//input first name
	static String iLastName;		//input last name
	static String iFirstToyName; 	//input first toy name
	static String iFirstToyPrice;	//input first toy price
	static String iSecToyName; 		//input second toy name
	static String iSecToyPrice;		//input second toy price
	static double cFirstToyPrice; 	//calculated first toy price
	static double cSecToyPrice; 	//calculated second toy price
	static double cSubtotal; 		//calculated subtotal 
	static double cTax; 			//calculated tax
	static double cTotal;			//calculated total
	static String oFirstToyPrice; 	//formatted output first toy price
	static String oSecToyPrice; 	//formatted output second toy price
	static String oSubtotal; 		//formatted output subtotal
	static String oTax; 			//formatted output tax
	static String oTotal; 			//formatted output total
	static Scanner myScanner; 		//input device
	static NumberFormat nf; 		//used to format currency

	public static void main(String[] args) {
		//call init()
		init();
		
		//call input
		input();
		
		//call calcs()
		calcs();
		
		//call output
		output();
		
		System.out.println("Merry Chirstmas!");
	}
	 
	public static void init() {
		//set scanner to the console
		myScanner = new Scanner(System.in);
		
		//change delimiter from blank space to enter key
		//allow spaces in strings
		myScanner.useDelimiter(System.getProperty("line.separator"));
					
		//set formatter to use us currency format
		nf = NumberFormat.getCurrencyInstance(java.util.Locale.US);				
	}
	
	public static void input() {
		//prompt for first name
		System.out.print("Enter first name: ");
		iFirstName = myScanner.next();
				
		//prompt for last name
		System.out.print("Enter last name: ");
		iLastName = myScanner.next();
						
		//prompt for first toy name
		System.out.print("Enter name for first toy: ");
		iFirstToyName = myScanner.next();
		
		
		try {
			//prompt for first toy price
		System.out.print("Enter price for first toy: ");
		iFirstToyPrice = myScanner.next();
		cFirstToyPrice = Double.parseDouble(iFirstToyPrice);
		}
		
		catch (Exception e){
			System.out.println("Price must a number. Default is set to 0. ");
			cFirstToyPrice = 0;
		}		
		
		//prompt for first toy name
		System.out.print("Enter name for second toy: ");
		iSecToyName = myScanner.next();
		
		try {				
		//prompt for second toy price
		System.out.print("Enter price for second toy: ");
		iSecToyPrice = myScanner.next();
		cSecToyPrice = Double.parseDouble(iSecToyPrice);					
		}
		
		catch (Exception e){
		System.out.println("Price must a number. Default is set to 0. ");
		cFirstToyPrice = 0;
		}	
	
}
	
	public static void calcs() {
		//calculate subtotal
		cSubtotal = cFirstToyPrice + cSecToyPrice; 
		//calculate tax
		cTax = cSubtotal * .07;
		//calculate total	
		cTotal = cSubtotal + cTax; 				
	}
	
	public static void output() {
		//print first name and last name
		System.out.println("Child's name is: " + iFirstName + " " + iLastName);
		
		//print first toy name
		System.out.println("First toy's name: " + iFirstToyName);
		
		//print first toy price
		oFirstToyPrice = nf.format(cFirstToyPrice);
		System.out.println("Price of first toy is: " + oFirstToyPrice);
		
		//print second toy name
		System.out.println("Second toy's name: " + iSecToyName);
		
		//print second toy price
		oSecToyPrice = nf.format(cSecToyPrice);
		System.out.println("Price of second toy is: " + oSecToyPrice);
		
		//format and output subtotal
		oSubtotal = nf.format(cSubtotal);
		System.out.println("Your subtotal is: " + oSubtotal);		
		
		//format and output tax
		oTax = nf.format(cTax);
		System.out.println("Your tax is: " + oTax);		
		
		//format and output total
		oTotal = nf.format(cTotal);
		System.out.println("Your total is: " + oTotal);		
	}
}
