import java.util.*;

public class ArrayExample {
	static Scanner myScanner; 
	static char[] arrDeskTypes = {'O', 'C', 'M'};
	static String[] arrDeskNames = {"Oak", "Cherry", "Mahogany" };
	static double[] arrDeskPrices = {600, 750, 875};
	static int[] arrDeskSold = new int[arrDeskTypes.length];
	static char iType;
	static String iSold;
	static int cSold;
	static char again = 'Y';
	static int index = -1;

	public static void main(String[] args) {
		
		init();
		
		do {
			input();
			calcs();
			try {
				System.out.println("Enter another sale? Y or N: ");		
				again = myScanner.nextLine().trim().toUpperCase().charAt(0);
			} catch (Exception e) {
				System.out.println("Invalid, defaulted to Y");		
			}
		}while(again == 'Y');
		
		summary();		
		
	}
	
	static void init() {
		myScanner = new Scanner(System.in);
		for(int i = 0; i < arrDeskTypes.length; i++) {
			arrDeskSold[i] = 0;
		}
	}
	
	static void input() {
		index = -1;
		try {
			System.out.println("Enter desk type (O, C, M): ");		
			iType = myScanner.nextLine().trim().toUpperCase().charAt(0);
			for(int i = 0; i < arrDeskTypes.length; i++) {
				if(iType == arrDeskTypes[i]) {
					index = i;
				}
			}
			if(index < 0) {
				System.out.println("Desk type invalid");
				return;
			}
		} catch (Exception e) {
			System.out.println("Desk type invalid");
			return;
		}
		
		try {
			System.out.println("Enter number of " + arrDeskNames[index] + " sold: ");
			cSold = Integer.parseInt(myScanner.nextLine());
			//arrDeskSold[index]+= cSold;
		} catch (Exception e) {
			System.out.println("Desks sold must be numeric");
			cSold = 0;
			return;
		}
				
	}
	
	static void calcs() {
		if(index >= 0) {
			arrDeskSold[index]+= cSold;
		}
	}
	
	static void summary() {
		System.out.println("\nName        # Sold         Total\n");
		for(int i = 0; i < arrDeskTypes.length; i+=2) {
			System.out.format("%-10s%5s%3d%5s%9.2f\n", arrDeskNames[i], " ", arrDeskSold[i]," ", (arrDeskSold[i] * arrDeskPrices[i]));
		}
	}
}
